t = int(input())
for _ in range(t):
    n = int(input())
    print('YES' if n % 8 == 0 else 'NO')

